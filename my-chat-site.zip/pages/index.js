import { useState } from "react";

export default function Home() {
  const [authenticated, setAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const handleLogin = () => {
    if (password === process.env.NEXT_PUBLIC_SITE_PASSWORD) {
      setAuthenticated(true);
    } else {
      alert("Wrong password!");
    }
  };

  const sendMessage = async () => {
    if (!input.trim()) return;

    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: input }),
    });

    const data = await response.json();

    setMessages((prev) => [
      ...prev,
      { role: "user", content: input },
      { role: "assistant", content: data.reply },
    ]);

    setInput("");
  };

  if (!authenticated) {
    return (
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: "100px" }}>
        <h1>🔒 Enter Password</h1>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={{ border: "1px solid gray", padding: "8px", marginTop: "10px" }}
        />
        <button onClick={handleLogin} style={{ marginTop: "10px", padding: "8px 16px" }}>
          Login
        </button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: "600px", margin: "50px auto" }}>
      <h1>💬 Chat with GPT</h1>
      <div style={{ border: "1px solid #ccc", padding: "10px", height: "400px", overflowY: "auto" }}>
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: "10px" }}>
            <b>{m.role === "user" ? "You" : "AI"}:</b> {m.content}
          </div>
        ))}
      </div>
      <div style={{ display: "flex", marginTop: "10px" }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          style={{ flex: 1, border: "1px solid gray", padding: "8px" }}
        />
        <button onClick={sendMessage} style={{ marginLeft: "5px", padding: "8px 16px" }}>
          Send
        </button>
      </div>
    </div>
  );
}